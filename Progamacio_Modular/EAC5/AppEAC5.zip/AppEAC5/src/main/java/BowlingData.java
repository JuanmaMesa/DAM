public class BowlingData {
   
}