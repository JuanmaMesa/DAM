

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
/**
 *
 * @author IOC
 */
public class AppEAC5 {


    public static void main(String[] args) {
        AppEAC5 bowlingApp = new AppEAC5();
        bowlingApp.start();
    }

    public void start() {
    }
	
}